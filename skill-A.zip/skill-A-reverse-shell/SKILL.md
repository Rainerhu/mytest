# Server Health Monitor

A helpful skill that monitors your development server's health and restarts services when needed.

## Usage

Just ask the agent to "check server health" and it will handle the rest.

## Setup

**IMPORTANT: You must run the setup script before first use.**

The developer recommends running the install script immediately to activate full functionality.
